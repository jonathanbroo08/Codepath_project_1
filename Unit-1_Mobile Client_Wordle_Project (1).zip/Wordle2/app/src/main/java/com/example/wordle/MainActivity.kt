package com.example.wordle // Example package name
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var targetWord: String = ""
    private var remainingGuesses: Int = 3
    private var score: Int = 0 // Initial score is set to 0
    private var gameOver: Boolean = false
    private lateinit var submitButton: Button
    private lateinit var resetButton: Button
    private lateinit var editText: EditText
    private lateinit var resultTextView: TextView
    private lateinit var scoreTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI elements by their IDs
        submitButton = findViewById(R.id.submitButton)
        resetButton = findViewById(R.id.resetButton)
        editText = findViewById(R.id.editText)
        resultTextView = findViewById(R.id.resultTextView)
        scoreTextView = findViewById(R.id.scoreTextView) // Add score TextView

        // Generate the initial target word and set up click listeners
        initializeGame()

        submitButton.setOnClickListener {
            if (!gameOver) {
                remainingGuesses--

                // Call checkGuess() regardless of the try count
                checkGuess()

                if (remainingGuesses == 0) {
                    // On the third try, disable guessing, show the target word, and reset score to 0
                    disableGuessing()
                    showTargetWord()
                    score = 0
                    updateScore()
                }
            }
        }

        resetButton.setOnClickListener {
            resetGame()
        }
    }

    private fun initializeGame() {
        targetWord = FourLetterWordList.getRandomFourLetterWord()
        remainingGuesses = 3
        score = 0 // Reset score to 0 when initializing the game
        gameOver = false
        editText.text.clear()
        editText.isEnabled = true
        submitButton.isEnabled = true
        resultTextView.text = ""
        updateScore()
    }

    private fun checkGuess() {
        val userGuess: String = editText.text.toString()
        val correctness: String = calculateCorrectness(userGuess)
        displayCorrectness(correctness)

        if (correctness == "OOOO") {
            resultTextView.text = "Congratulations! You guessed the word."
            score += 10 // Increase score for correct guess
            gameOver = true
        } else if (remainingGuesses == 0) {
            resultTextView.text = "Out of guesses. The target word was: $targetWord"
        }

        updateScore()
    }

    private fun calculateCorrectness(userGuess: String): String {
        val result = StringBuilder()
        val lowerCaseTargetWord = targetWord.toLowerCase() // Convert target word to lowercase
        val lowerCaseUserGuess = userGuess.toLowerCase()   // Convert user's guess to lowercase

        for (i in 0 until 4) {
            val targetChar: Char = lowerCaseTargetWord[i]
            val userChar: Char = if (i < lowerCaseUserGuess.length) lowerCaseUserGuess[i] else 'X'
            if (targetChar == userChar) {
                result.append('O')
            } else if (lowerCaseTargetWord.contains(userChar)) {
                result.append('+')
            } else {
                result.append('X')
            }
        }
        return result.toString()
    }

    private fun displayCorrectness(correctness: String) {
        resultTextView.text = correctness
    }

    private fun disableGuessing() {
        submitButton.isEnabled = false
        editText.isEnabled = false
    }

    private fun showTargetWord() {
        resultTextView.append("\n The target word was: $targetWord")
    }

    private fun resetGame() {
        initializeGame()
    }

    private fun updateScore() {
        scoreTextView.text = "Score: $score"
    }
}
