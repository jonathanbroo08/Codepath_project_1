package com.example.wordle

object FourLetterWordList {
    private val words = arrayOf(
        "word", "game"
        // Make sure to include at least 3-4 letter words
    )

    private val random = java.util.Random()

    fun getRandomFourLetterWord(): String {
        val fourLetterWords = words.filter { it.length == 4 }
        if (fourLetterWords.isNotEmpty()) {
            val randomIndex = random.nextInt(fourLetterWords.size)
            return fourLetterWords[randomIndex].toUpperCase() // Optionally convert to uppercase
        }
        return "WORD" // Default word if the list is empty
    }
}
